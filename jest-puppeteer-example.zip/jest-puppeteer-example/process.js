const dotenv = require('dotenv');
dotenv.config();

console.log(process.env.HEAD_LESS);
const x = process.env.HEAD_LESS || true;
console.log(x);