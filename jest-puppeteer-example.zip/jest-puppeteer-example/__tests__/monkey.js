const timeout = 10000

describe(
  '/ (Survey Monkey)',
  () => {
    let page
    beforeAll(async () => {
      page = await global.__BROWSER__.newPage();
      await page.goto('https://zh.surveymonkey.com/r/EmployeeHealthCheck');
    }, timeout)

    afterAll(async () => {
      await page.close()
    })

    it('should load without error', async () => {
      await page.$$eval('input', (inputs) => inputs.map((input) => {input.click()}));
      await page.type('input[name="486014830"]', '024345');
      await page.type('input[name="486014831"]', '36.5');
      await page.click('button')
      await page.waitForSelector('strong > span');
      const textCompleted = await page.$eval('strong > span', e => e.innerText);
      console.log(textCompleted);
      expect(textCompleted).toContain('已完成體溫回報!');
    })
  }, timeout)
